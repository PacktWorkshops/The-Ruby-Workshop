require "./exercise_4a"

users = ['John', 'Susy', 'Sarah', 'James']
UserLister.new(users).perform