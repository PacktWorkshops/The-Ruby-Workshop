File.foreach('company.txt') do |row|
  puts row
end
