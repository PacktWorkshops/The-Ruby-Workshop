> num = 2.339 

 => 2.339 

 

> num.ceil 

 => 3 

> num.floor 

 => 2 
 
 > num.next_float 

 => 2.3390000000000004 

> num.prev_float 

 => 2.3389999999999995 
 
 > num.round 

 => 2 

> num.round(2) 

 => 2.34 