> 2.next 

 => 3 
 
 > 2.pred 

 => 1 
 
 > 2.lcm(3) 

 => 6 
 
 > 2.gcd(3) 

 => 1 