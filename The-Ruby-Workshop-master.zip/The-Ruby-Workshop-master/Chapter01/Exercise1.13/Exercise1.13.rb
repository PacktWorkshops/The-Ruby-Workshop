title = "My Favorite Java book is Java Fundamentals" 

 => "My Favorite Java book is Java Fundamentals" 

 

> title.gsub("Java", "Ruby") 

 => "My Favorite Ruby book is Ruby Fundamentals" 

 
 