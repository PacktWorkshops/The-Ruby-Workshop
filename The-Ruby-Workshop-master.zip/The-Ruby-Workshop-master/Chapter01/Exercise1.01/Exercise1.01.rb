> number_of_students = 17 + 13 

 => 30 

> puts number_of_students 

 => 30 