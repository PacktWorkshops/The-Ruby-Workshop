> title = "My Favorite book is Ruby Fundamentals" 

 => "My Favorite book is Ruby Fundamentals"  

 

> title.split 

 => ["My", "Favorite", "book", "is", "Ruby", "Fundamentals"] 
 
 > months = "Jan; Feb; Mar" 

 => "Jan; Feb; Mar" 

 

 > months.split(';') 

 => ["Jan", " Feb", " Mar"] 
 
 > data = ["My", "Favorite", "book", "is", "Ruby", "Fundamentals"] 

 => ["My", "Favorite", "book", "is", "Ruby", "Fundamentals"] 

  

> data.join 

 => "MyFavoritebookisRubyFundamentals"  

 
 