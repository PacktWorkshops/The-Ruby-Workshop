puts "Enter your first name: "
first_name = gets.chomp
puts "Enter your last name: "
last_name = gets.chomp
puts "#{first_name}#{last_name}@rubyprogram.com"
