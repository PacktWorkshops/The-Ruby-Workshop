> title = "ruby fundamentals" 

 => "ruby fundamentals" 
 
 > title.size 

 => 17 
 
 > title.length 

 => 17 
 
 > title.upcase 

 => "RUBY FUNDAMENTALS" 
 
 > title.downcase 

 => "ruby fundamentals" 
 
 > title.capitalize 

 => "Ruby fundamentals" 
 
 > title 

 => "ruby fundamentals" 
 
 > title.capitalize! 

 => "Ruby fundamentals" 

> title 

 => "Ruby fundamentals" 
 
 