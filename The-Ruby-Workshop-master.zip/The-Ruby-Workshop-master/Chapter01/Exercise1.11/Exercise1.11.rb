quote = "Just Do IT" 

 => "Just Do IT" 

> quote[8,2] 

 => "IT" 
 
 
 quote = "Just Do IT" 

 => "Just Do IT" 

 

> quote.include?("Just") 

 => true 

 

 > quote.include?("just") 

 => false 



 
 