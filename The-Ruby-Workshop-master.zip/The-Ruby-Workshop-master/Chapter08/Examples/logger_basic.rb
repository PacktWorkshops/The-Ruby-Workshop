require 'logger'

logger = Logger.new(STDOUT)
logger.debug("User 23643 logged in")