class Vote
end
