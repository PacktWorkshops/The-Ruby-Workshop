class ExitController < Controller
  def run
    log "Exiting..."
  end
end
