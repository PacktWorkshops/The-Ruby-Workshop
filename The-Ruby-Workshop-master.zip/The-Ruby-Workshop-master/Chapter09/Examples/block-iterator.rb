def star_tree number 
    1.upto(number).each do |i|
        puts "*" * i 
    end
end

star_tree 30