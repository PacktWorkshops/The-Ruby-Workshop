#syntax 1 using lambda keyword
hello = lambda {puts "Hello World"}

hello.call

#syntax 2 using staby labda
hello = -> {puts "Hello World"}

hello.call