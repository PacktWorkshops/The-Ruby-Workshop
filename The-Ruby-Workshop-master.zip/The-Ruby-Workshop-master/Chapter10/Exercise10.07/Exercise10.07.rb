class RubyFundamental
  def self.hello
    puts "Hello World this is my first gem!"
  end
end