class String 
	def add_prefix
		"My favorite book is " + self
	end
end

puts "Ruby Fundamentals".add_prefix

