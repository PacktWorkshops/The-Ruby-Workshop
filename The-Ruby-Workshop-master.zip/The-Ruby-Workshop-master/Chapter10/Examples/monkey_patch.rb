class Array 
    def size
        self.length + 3
    end
end

my_array = ["Hello", "World"]
puts my_array.size

