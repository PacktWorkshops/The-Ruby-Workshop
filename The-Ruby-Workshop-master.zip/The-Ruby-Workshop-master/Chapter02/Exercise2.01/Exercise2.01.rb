#merging two arrays
colors_1 = ['violet', 'indigo', 'blue', 'green']
colors_2 = ['yellow', 'violet', 'orange', 'red', 'violet']
colors_3 = colors_1 + colors_2

#removing an element from array
colors_repeated = ['violet']
colors_new = colors_3 - colors_repeated

#pushing new elements into an array
colors_1.push('yellow')
colors_1.push('red')
colors_2.push('green')
colors_2.push('blue')

#selecting last element of the array
colors_1 = ['violet', 'indigo', 'blue', 'green']
colors_1.

#removing last elemnt from the array
colors_1 = ['violet', 'indigo', 'blue', 'green']
colors_1.pop
colors_1