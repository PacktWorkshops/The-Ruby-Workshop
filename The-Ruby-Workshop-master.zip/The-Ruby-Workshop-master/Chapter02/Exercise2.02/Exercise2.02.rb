#freezing an array
my_array = [1,2,3,4,5,6,6,4,3,2,1]
my_array.freeze

#listing unique elements of an array
my_uniq_arry = my_array.uniq

#sorting elements of an array
my_sorted_array = my_array.sort

#finding size and length of an array
my_array.size
my_array.length

#finding if an element exists within an array
my_array.include?(1)
my_array.include?(11)

#converting the elements of an array into a string
my_array.inspect